// import { loadNavbar } from "/navbar/utils/loadNavbar.js";

// document.addEventListener("DOMContentLoaded", () => {
//   loadNavbar(); // Load the navbar
// });
